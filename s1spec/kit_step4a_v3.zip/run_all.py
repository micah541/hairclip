#!/usr/bin/env python3
"""Reproduction kit A for step 4:  Gamma0 certificate + the P1 validated Fourier chain (slabs 1..96).

    python run_all.py                  run (or RESUME) everything; ends with the check table.  Safe to interrupt (Ctrl-C, reboot): run the same command again.
    python run_all.py --status         show progress of an existing run and exit
    python run_all.py --max-slabs N    test run: stop the chain after slab N (check.py then reports a PARTIAL result)
    python run_all.py --force-gamma0   redo the Gamma0 certificate even if it is already done
    python run_all.py --clean          delete kit_out/ (all results) and exit

Stages (each is a separate Python process, one at a time, single-threaded BLAS, PYTHONHASHSEED=0):
  1. gamma0   t2/gamma0.py final  (G0SNAP = t2/gamma0s_src.npz, the two-pass slaved source)  -> kit_out/gamma0/gamma0_final.json
              Krawczyk closure of b_2 + embeddedness.  About 3 min.
  2. p1       t3/run_p1.py --target-k 25 --Mmax 3600   (stops at slab 95, k_max >= 25)
              t3/run_p1.py --target-k 28 --Mmax 3600   (one more slab, 96: the P1 -> P2 switch state)
              starting from the Gamma0 of stage 1; checkpoints kit_out/p1/ckpt/slab_NNNNN.{json,npz}.  Hours.
Logs: kit_out/logs/*.log     Progress: this console, kit_out/p1/status.json"""
import os, sys

# --- environment for this process and all children (must be set before anything numeric is imported) -------------------------
FORCED_ENV = dict(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1',
                  VECLIB_MAXIMUM_THREADS='1', BLIS_NUM_THREADS='1', PYTHONHASHSEED='0', PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
os.environ.update(FORCED_ENV)
os.environ.pop('PYTHONPATH', None)

import json, time, re, subprocess, platform, shutil, collections

try: sys.stdout.reconfigure(encoding='utf-8', errors='replace'); sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception: pass

KIT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(KIT, 'kit_out')
LOGS = os.path.join(OUT, 'logs')
G0DIR = os.path.join(OUT, 'gamma0')
P1DIR = os.path.join(OUT, 'p1')
CKPT = os.path.join(P1DIR, 'ckpt')
G0JSON = os.path.join(G0DIR, 'gamma0_final.json')
NSLABS = 96                    # slabs 1..96 (slab 0 = Gamma0); 95 reaches k_max >= 25, slab 96 is the extra slab for the P1 -> P2 switch
PHASES = (25.0, 28.0)          # --target-k of the two run_p1.py invocations (as in the reference run)
MMAX = 3600
MSTEP_FROM = 90                # reference schedule: old +80 M-step for the resize decisions after slabs <= 89, max(80, 0.15 M) from slab 90 on
PINS = dict(flint='0.9.0', numpy='2.5.4', scipy='1.18.1', sympy='1.14.0', mpmath='1.3.0')


def hms(s):
    if s is None or s != s: return '?'
    s = int(round(s)); return f'{s // 3600}h{(s % 3600) // 60:02d}m' if s >= 3600 else f'{s // 60}m{s % 60:02d}s'


def now(): return time.strftime('%H:%M:%S')


# --------------------------------------------------------------------------------------------------------- single-instance lock
_LOCK = None
def acquire_lock():
    """OS-level lock held for the life of the process (released automatically when the process dies: reboot/kill leave no stale lock)."""
    global _LOCK
    os.makedirs(OUT, exist_ok=True)
    f = open(os.path.join(OUT, 'run.lock'), 'a+')
    try:
        if os.name == 'nt':
            import msvcrt; f.seek(0); msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl; fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print('Another run_all.py is already running in this folder (kit_out\\run.lock is locked). Not starting a second one.'); sys.exit(3)
    _LOCK = f


# --------------------------------------------------------------------------------------------------------- helpers on checkpoints
def ckpt_numbers():
    try: names = os.listdir(CKPT)
    except OSError: return []
    return sorted(int(m.group(1)) for n in names for m in [re.fullmatch(r'slab_(\d{5})\.json', n)] if m)


def read_ckpt(k):
    try:
        with open(os.path.join(CKPT, f'slab_{k:05d}.json'), encoding='utf-8') as f: return json.load(f)
    except Exception: return None


def latest_slab():
    for k in reversed(ckpt_numbers()):
        r = read_ckpt(k)
        if r and r.get('complete') and os.path.exists(os.path.join(CKPT, f'slab_{k:05d}.npz')): return k, r
    return None, None


def load_ref_cpu():
    try:
        with open(os.path.join(KIT, 'reference', 'p1_ref.json'), encoding='utf-8') as f: ref = json.load(f)
        return [s.get('cpu') or 0.0 for s in ref['slabs']]          # index = slab number (slab 0: 0)
    except Exception: return [0.0] * (NSLABS + 1)


def p1_complete():
    try:
        with open(os.path.join(P1DIR, 'status.json'), encoding='utf-8') as f: st = json.load(f)
        return bool(st.get('done')) and float(st.get('target_k', 0)) >= PHASES[-1] and int(st.get('slab', 0)) >= NSLABS
    except Exception: return False


# --------------------------------------------------------------------------------------------------------- progress monitor for the chain
class Progress:
    def __init__(self, total):
        self.total = total; self.ref = load_ref_cpu(); self.t0 = time.time(); self.seen = None
        self.win = collections.deque(maxlen=11)     # (detect time, slab, cpu of that slab) of slabs finished in this session
        self.last_change = time.time(); self.last_beat = time.time(); self.last_cpu = None; self.base_elapsed = 0.0

    def eta(self, k, rec):
        rem_ref = sum(self.ref[k + 1:self.total + 1])
        hist = rec.get('history', [])
        n = min(10, len(hist))
        a = sum(h['cpu'] for h in hist[-n:]); b = sum(self.ref[h['slab']] for h in hist[-n:])
        ratio = a / b if b > 0 else None                          # this machine's CPU time / reference CPU time (last 10 slabs)
        if len(self.win) >= 4:                                      # wall time per reference-cpu-second over the finished slabs of this session
            t_first = self.win[0][0]; t_last = self.win[-1][0]
            bref = sum(self.ref[s] for _, s, _ in list(self.win)[1:])
            if bref > 0: ratio_w = (t_last - t_first) / bref
            else: ratio_w = None
        else: ratio_w = None
        r = ratio_w if ratio_w else ratio
        return (rem_ref * r if r else None), ratio

    def poll(self):
        k, rec = latest_slab()
        if k is None:
            if time.time() - self.last_beat > 300:
                print(f'[{now()}] [P1] starting (building Gamma0 state)...', flush=True); self.last_beat = time.time()
            return
        t = time.time()
        if self.seen is None:
            self.seen = k; self.last_change = t; self.last_beat = t
            print(f'[{now()}] [P1] at slab {k} of {self.total} when this session started', flush=True)
            self.win.append((t, k, 0.0))
            return
        if k != self.seen:
            h = rec['history'][-1] if rec.get('history') else {}
            cpu = h.get('cpu', 0.0)
            self.win.append((t, k, cpu))
            eta, ratio = self.eta(k, rec)
            tt = ''
            if rec.get('t'):
                try: tt = f"  t={self._t(rec)}"
                except Exception: pass
            km = f"  k_max in [{h['kmax'][0]:.4f}, {h['kmax'][1]:.4f}]" if h.get('kmax') else ''
            print(f"[{now()}] [P1] slab {k:2d} of {self.total}  slab cpu {hms(cpu)}  M={rec['M']} block={rec['d']} attempt={h.get('attempt', '?')}"
                  f"  | this session {hms(t - self.t0)}  | cpu so far {hms(rec.get('cpu_total'))}"
                  f"  | ETA ~{hms(eta)}" + (f" (speed {ratio:.2f}x reference)" if ratio else '') + tt + km, flush=True)
            self.seen = k; self.last_change = t; self.last_beat = t; self.last_cpu = cpu
        elif t - self.last_beat > 300:
            nxt = self.ref[k + 1] if k + 1 < len(self.ref) else 0
            print(f"[{now()}] [P1] slab {k + 1} of {self.total} running for {hms(t - self.last_change)}"
                  f" (the sandbox needed {hms(nxt)} cpu for it; the late slabs are the longest)", flush=True)
            self.last_beat = t

    @staticmethod
    def _t(rec):
        m, e, rm, re_ = rec['t']; v = int(m) * 2.0 ** int(e); return f'{v:.12f}'


# --------------------------------------------------------------------------------------------------------- child process runner
def run_child(label, cmd, cwd, env_extra, log_path, mode='w', monitor=None, beat=None):
    env = dict(os.environ); env.update(FORCED_ENV); env.pop('PYTHONPATH', None); env.update(env_extra or {})
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    kw = {}
    if os.name == 'nt': kw['creationflags'] = getattr(subprocess, 'BELOW_NORMAL_PRIORITY_CLASS', 0)   # keeps the PC usable; same console, so Ctrl-C reaches the child
    t0 = time.time()
    with open(log_path, mode, encoding='utf-8') as lf:
        lf.write(f'\n===== {time.strftime("%Y-%m-%d %H:%M:%S")}  {" ".join(cmd)}  (cwd {cwd})\n'); lf.flush()
        p = subprocess.Popen(cmd, cwd=cwd, env=env, stdout=lf, stderr=subprocess.STDOUT, **kw)
        last = time.time()
        try:
            while True:
                try: rc = p.wait(timeout=10); break
                except subprocess.TimeoutExpired: pass
                if monitor: monitor.poll()
                elif beat and time.time() - last > beat:
                    print(f'[{now()}] [{label}] still running ({hms(time.time() - t0)})...', flush=True); last = time.time()
        except KeyboardInterrupt:
            print('\nInterrupted: stopping the child process (checkpoints are atomic; nothing is lost except the slab in progress).', flush=True)
            try: p.wait(timeout=20)
            except Exception:
                p.terminate()
                try: p.wait(timeout=20)
                except Exception: p.kill()
            print('Run  python run_all.py  again to continue.', flush=True); raise SystemExit(130)
    if monitor: monitor.poll()
    return rc, time.time() - t0


def tail(path, n=25):
    try:
        with open(path, encoding='utf-8', errors='replace') as f: return ''.join(f.readlines()[-n:])
    except OSError: return '(no log)'


TIMES = {}
def save_times():
    os.makedirs(OUT, exist_ok=True)
    old = {}
    try:
        with open(os.path.join(OUT, 'timing.json'), encoding='utf-8') as f: old = json.load(f)
    except Exception: pass
    for k, v in TIMES.items():
        if k in old and isinstance(old[k], dict) and 'wall_s' in old[k]: v['wall_s_previous_sessions'] = old[k].get('wall_s_previous_sessions', 0) + old[k]['wall_s']
        old[k] = v
    with open(os.path.join(OUT, 'timing.json'), 'w', encoding='utf-8') as f: json.dump(old, f, indent=1)


# --------------------------------------------------------------------------------------------------------- stages
def write_env():
    info = dict(python=sys.version, platform=platform.platform(), machine=platform.machine(), processor=platform.processor(), cpu_count=os.cpu_count(),
                forced_env=FORCED_ENV, started=time.strftime('%Y-%m-%d %H:%M:%S'))
    ok = True
    try:
        import flint, numpy, scipy, sympy, mpmath
        v = dict(flint=flint.__version__, numpy=numpy.__version__, scipy=scipy.__version__, sympy=sympy.__version__, mpmath=mpmath.__version__)
        info['versions'] = v; info['pinned'] = PINS
        for k, want in PINS.items():
            if v[k] != want: print(f'  note: {k} is {v[k]}, the reference run used {want}')
        try:
            info['numpy_blas'] = str(numpy.show_config(mode='dicts').get('Build Dependencies', {}).get('blas', {}))
        except Exception: pass
    except Exception as e:
        info['import_error'] = repr(e); ok = False
        print('  ERROR: cannot import the required packages (' + repr(e) + '). Activate the venv and run: python -m pip install -r requirements.txt')
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, 'env.json'), 'w', encoding='utf-8') as f: json.dump(info, f, indent=1)
    if not sys.version.startswith('3.13'): print(f'  note: Python {sys.version.split()[0]}; the reference run used 3.13')
    return ok


def stage_gamma0(force):
    done = os.path.join(G0DIR, 'gamma0.done')
    if os.path.exists(done) and os.path.exists(G0JSON) and not force:
        print(f'[{now()}] [gamma0] already done (kit_out\\gamma0\\gamma0.done); skipping.  --force-gamma0 redoes it.', flush=True); return True
    os.makedirs(G0DIR, exist_ok=True)
    for f in (done, G0JSON):
        if os.path.exists(f): os.remove(f)
    print(f'[{now()}] [gamma0] Krawczyk closure of b_2 + embeddedness of Gamma0 (about 3 min; no output until it ends)...', flush=True)
    log = os.path.join(LOGS, 'gamma0.log')
    rc, dt = run_child('gamma0', [sys.executable, 'gamma0.py', 'final'], os.path.join(KIT, 't2'),
                       dict(G0SNAP='gamma0s_src.npz', G0FINAL=os.path.relpath(G0JSON, os.path.join(KIT, 't2'))), log, beat=60)
    ok = rc == 0 and os.path.exists(G0JSON)
    TIMES['gamma0'] = dict(wall_s=round(dt, 1), returncode=rc)
    save_times()
    if ok:
        with open(done, 'w') as f: f.write(time.strftime('%Y-%m-%d %H:%M:%S') + f'  wall {dt:.0f}s\n')
        print(f'[{now()}] [gamma0] ok ({hms(dt)})', flush=True)
    else:
        print(f'[{now()}] [gamma0] FAILED (rc={rc}); last log lines:\n{tail(log)}', flush=True)
    return ok


def stage_p1(max_slabs):
    total = min(NSLABS, max_slabs) if max_slabs else NSLABS
    if p1_complete() and not max_slabs:
        print(f'[{now()}] [P1] already complete (slab {NSLABS}, k_max >= {PHASES[-1]:g}); nothing to run.', flush=True); return True
    if not os.path.exists(G0JSON):
        print('[P1] kit_out\\gamma0\\gamma0_final.json is missing: the gamma0 stage has to succeed first.'); return False
    k, _ = latest_slab()
    print(f'[{now()}] [P1] {"resuming from slab %d" % k if k is not None else "starting from Gamma0"}; target: {total} slabs'
          f'.  Expect hours; progress lines follow.', flush=True)
    log = os.path.join(LOGS, 'p1.log'); t0 = time.time(); rc = 0
    prog = Progress(total)
    for target in PHASES:
        k, _ = latest_slab()
        if max_slabs and k is not None and k >= max_slabs: break
        cmd = [sys.executable, '-u', 'run_p1.py', '--target-k', f'{target:g}', '--Mmax', str(MMAX), '--mstep-from', str(MSTEP_FROM), '--gamma0', G0JSON, '--out', P1DIR]
        if max_slabs: cmd += ['--max-slabs', str(max_slabs)]
        rc, _dt = run_child('P1', cmd, os.path.join(KIT, 't3'), {}, log, mode='a', monitor=prog)
        if rc != 0: break
    dt = time.time() - t0
    TIMES['p1'] = dict(wall_s=round(dt, 1), returncode=rc, slabs_done=latest_slab()[0])
    save_times()
    if rc != 0:
        print(f'[{now()}] [P1] FAILED (rc={rc}); last log lines:\n{tail(log)}\nRunning  python run_all.py  again resumes from the last checkpoint; if it fails at the same slab, paste kit_out\\logs\\p1.log.', flush=True)
        return False
    k, _ = latest_slab()
    print(f'[{now()}] [P1] stopped at slab {k} ({hms(dt)} this session)', flush=True)
    return True


def show_status():
    k, rec = latest_slab()
    if k is None: print('no P1 checkpoint yet'); return
    ref = load_ref_cpu(); hist = rec.get('history', [])
    done_cpu = sum(h['cpu'] for h in hist); done_ref = sum(ref[h['slab']] for h in hist)
    rem = sum(ref[k + 1:NSLABS + 1]); ratio = done_cpu / done_ref if done_ref else None
    print(f'P1: slab {k} of {NSLABS} done; cpu so far {hms(done_cpu)}; complete: {p1_complete()}'
          + (f'; remaining ~{hms(rem * ratio)} at {ratio:.2f}x the reference cpu time' if ratio and k < NSLABS else ''))
    print('gamma0 stage:', 'done' if os.path.exists(os.path.join(G0DIR, 'gamma0.done')) else 'not done')


def main():
    a = sys.argv[1:]
    if '-h' in a or '--help' in a: print(__doc__); return 0
    if '--status' in a: show_status(); return 0
    if '--clean' in a:
        shutil.rmtree(OUT, ignore_errors=True); print('kit_out deleted.'); return 0
    ms = None
    if '--max-slabs' in a:
        try: ms = int(a[a.index('--max-slabs') + 1]); assert 1 <= ms <= NSLABS
        except Exception: print('usage: --max-slabs N   (1 <= N <= 96)'); return 2
    unknown = [x for x in a if x.startswith('-') and x not in ('--max-slabs', '--force-gamma0')]
    if unknown: print('unknown option(s):', unknown); print(__doc__); return 2
    acquire_lock()
    print(f'Kit 4A v3  |  {time.strftime("%Y-%m-%d %H:%M:%S")}  |  Python {sys.version.split()[0]}  |  {platform.platform()}', flush=True)
    if not write_env(): return 1
    t0 = time.time()
    ok = stage_gamma0('--force-gamma0' in a) and stage_p1(ms)
    print(f'\n[{now()}] stages finished ({"ok" if ok else "NOT ok"}), {hms(time.time() - t0)} in this session.', flush=True)
    if not ok: return 1
    print('Running check.py ...\n', flush=True)
    rc = subprocess.call([sys.executable, 'check.py'], cwd=KIT, env=dict(os.environ, **FORCED_ENV))
    return rc


if __name__ == '__main__':
    sys.exit(main())
