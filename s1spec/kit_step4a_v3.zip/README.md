# Reproduction kit 4A v3: start of step 4 (Gamma0 certificate + P1 validated Fourier chain)

**v3 changes:** `check.py` no longer requires slab-end enclosures of t, L, X0 to overlap the reference (the two chains choose float step sizes that differ in the last digits, so their slab-end times differ by up to 1e-15 and plain overlap is meaningless). It compares L and X0 at a common time (sanity check, WARN only) and keeps: every slab validated, k_max overlap, final-slab overlap, final k_max >= 28. `--mstep-from 90` is included (v2.1). A run that already finished with v2 need not be repeated: copy the new `check.py` over the old one and run `python check.py`.

What it reproduces (all arb / python-flint, one process at a time, no network, nothing outside this folder is touched):

1. **Gamma0 certificate** (`t2/gamma0.py final`, input `t2/gamma0s_src.npz`, the two-pass slaved source): Krawczyk closure of b_2 at 192 bits and embeddedness (701 arcs). About 3 min on the sandbox.
2. **P1 validated Fourier chain** (`t3/run_p1.py`, engine `t3/slab.py`): from the Gamma0 produced in stage 1 through all **96 slabs** (slab 0 = Gamma0, slabs 1..96 validated). Settings of the reference run, built into `run_all.py`:
   * `--target-k 25 --Mmax 3600`: stops at slab 95 (k_max enclosure >= 25);
   * then `--target-k 28 --Mmax 3600` on the same checkpoints: one extra slab, **96**, the P1 -> P2 switch state (k_max enclosure 29.35);
   * M-step schedule: `--mstep-from 90` (set by `run_all.py`): the old +80 step for the resize decisions after slabs 1-89 and max(80, 0.15 M) from slab 90 on, which reproduces the reference M sequence exactly (the Nov 10 patch was applied to the reference run mid-chain). `check.py` reports an M / block difference as INFO, not FAIL.
   * the M-step rule patch of Nov 10 (`max(80, 0.15 M)`) is in `t3/run_p1.py`.

The slaving step that made `gamma0s_src.npz` (`run_proto.py slave`) is not rerun: the snapshot is shipped as an input.

## Run it (Windows 11, PowerShell, unzipping to `C:\kit4a`)

```powershell
Expand-Archive -Path .\kit_step4a.zip -DestinationPath C:\kit4a
cd C:\kit4a
dir run_all.py                      # must exist here; if you see a kit_step4a subfolder, cd into it instead
py -3.13 -m venv kitenv
.\kitenv\Scripts\python.exe -m pip install --upgrade pip
.\kitenv\Scripts\python.exe -m pip install -r requirements.txt
.\kitenv\Scripts\python.exe run_all.py
.\kitenv\Scripts\python.exe check.py
```

(Calling `kitenv\Scripts\python.exe` directly avoids PowerShell's execution-policy problem with `Activate.ps1`. If you do activate the venv, plain `python run_all.py` and `python check.py` are the same commands.)

`run_all.py` runs the certificate, then the chain, then runs `check.py` itself, so the last thing printed is the table and the **SUMMARY (paste this)** block. Running `check.py` again later gives the same output (it is also saved in `kit_out\check_report.txt`).

Before you go to bed:
* plug the machine in and stop it sleeping: `powercfg /change standby-timeout-ac 0` and `powercfg /change monitor-timeout-ac 0` (or Settings > System > Power);
* leave the PowerShell window open (closing it stops the run; it is resumable anyway, see below);
* unzip to a short path outside OneDrive, as above; close other heavy jobs. Windows Update restarts are the usual cause of interruptions.

## What you see while it runs

```
[01:12:40] [P1] slab 41 of 96  slab cpu 1m41s  M=760 block=51 attempt=0  | this session 2h31m  | cpu so far 2h38m  | ETA ~7h50m (speed 1.9x reference)
[01:17:41] [P1] slab 90 of 96 running for 6m... (the sandbox needed ...)
```
One line per finished slab, a heartbeat every 5 minutes, and an ETA from the reference per-slab cpu times scaled by your machine's measured speed. **The slab count is not the time**: slabs get slower as the curve resolves, and the last 10 slabs are about 44 percent of the total (the sandbox needed 45 min cpu for slab 96 alone, so about 1.5 h on a machine twice as slow). Progress at any time, from a second window: `.\kitenv\Scripts\python.exe run_all.py --status` (harmless while the run goes on).

## Expected runtime

Reference (sandbox, cpu time): Gamma0 about 3 min; P1 **6.2 h** in total: slabs 1-9 1.05 h, 10-40 1.5 h, 41-75 0.6 h, 76-90 0.9 h, 91-96 2.2 h. At your measured speed (the step-3 kit ran about 2x slower than the sandbox) expect **8-12 h overnight**, 13 h if the machine is busy. One core is used; the other 7 are idle (the chain is sequential).

## Interrupted? (Ctrl-C, reboot, crash, power cut)

Run the same command again:

```powershell
cd C:\kit4a
.\kitenv\Scripts\python.exe run_all.py
```

It skips the finished Gamma0 stage and continues from the last complete slab checkpoint (`kit_out\p1\ckpt`; checkpoints are written atomically, a torn last file is ignored). Only the slab in progress is repeated. A second `run_all.py` started while one is running refuses to start. Other options: `--status`, `--force-gamma0`, `--max-slabs N` (test run, partial check), `--clean` (delete `kit_out`).

## Reading the check

`check.py` compares with `reference/` (the sandbox run). **Acceptance rule** (bit-identity is not expected on a different BLAS, because float approximate inverses may differ in the last bits, which moves the 128-bit centres and radii slightly):

* Gamma0: Krawczyk contraction holds, embeddedness holds, and the closing interval for b_2 overlaps ours;
* every one of the 96 slabs validates (a slab that needed a retry with h/2 is listed, it is still validated);
* every reported enclosure **overlaps** ours: t, L, X0 on all slabs, k_max on the slabs where it is reported (94-96), exact rational test;
* the final slab 96: t, L, X0, k_max overlap ours and the k_max enclosure is >= 28.

Reported but not required: relative differences of the error radii per field (`w_out, eta_intra, hull1, box1, box3, T`), bit-identity of centres, whether M / block / h agree with the reference on every slab, cpu ratio. `kit_out\check_slabs.csv` has the per-slab table. Status lines: PASS, FAIL, WARN (look, not a failure), INFO. The last line of the summary is **TOTAL PASS** or **TOTAL FAIL** (a run with fewer than 96 slabs prints PARTIAL).

If `M / block / h` differ from the reference at some slab, the discrete choices of the chain diverged there (a borderline float decision); the validated enclosures are then for slightly different time steps and the overlap test may fail without any error in the proof. The line says where; send the output.

## Send back

**Paste the output of `check.py`** (at least the SUMMARY block; the whole table is better). No zip is needed. If a stage fails, also paste the last 40 lines of `kit_out\logs\p1.log` (or `gamma0.log`).

## Files

`run_all.py` driver (forces single-threaded BLAS and `PYTHONHASHSEED=0`, lowers the priority of the child process, one process at a time, resumable) | `check.py` | `requirements.txt` (python-flint 0.9.0, numpy 2.5.4, scipy 1.18.1, sympy 1.14.0, mpmath 1.3.0) | `t2/` certificate | `t3/` engine and runner | `reference/` Gamma0 certificate output and log, `p1_ref.json` (per slab: enclosures of t, L, X0, k_max, error radii, M, block, h, cpu, hashes of the centres).
Source patches relative to the proof tree are marked `[kit patch]`: kit-relative paths instead of `/home/claude/...`, `os.nice` guarded (not on Windows), `os.replace` retried on `PermissionError`, `--Mmax` default 3600. No fork, threads, signals or shell calls are used.
