#!/usr/bin/env python3
"""Compare kit_out/ with the reference run (reference/) and print a PASS / FAIL table plus a short summary to paste back.

Acceptance rule (a different BLAS may change float approximate inverses, so 128-bit centres and radii need not be bit-identical):
  * the Gamma0 certificate completes (Krawczyk contraction, embeddedness) and its closing interval for b_2 overlaps ours;
  * every slab 1..96 validates (checkpoint written, no run failure);
  * the final slab's (96) enclosures t, L, X0 and k_max overlap ours and the final k_max enclosure lies above 28;
  * k_max enclosures overlap ours on every slab where the reference reports one.
Sanity check (v3, WARN only): slab-end times of two chains differ in the last digits (different float step-size controller), so enclosures of
t, L, X0 at slab ends are NOT comparable by plain overlap.  L and X0 are compared at a common time instead: |q_u - q_r| <= rad_u + rad_r + S_q (|t_u - t_r| + rad_t_u + rad_t_r),
S_q = 2 max |slope| of the reference over the two adjacent slabs (exact rational test).
Reported, not required: relative differences of the error radii, bit-identity of centres (hashes), slab discrete choices (M, block, h), cpu times.
A run with fewer than 96 slabs (--max-slabs test) gives a PARTIAL result over the slabs present.
usage: python check.py [--detail]     (also writes kit_out/check_report.txt and kit_out/check_slabs.csv)"""
import os, sys, json, math, re, statistics
from fractions import Fraction

try: sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception: pass

KIT = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(KIT, 'kit_out'); REF = os.path.join(KIT, 'reference')
NSLABS = 96; FINAL_K = 28.0; KIT_VERSION = 'v3'
rows = []
def add(status, name, detail=''): rows.append((status, name, detail))
def jl(p):
    try:
        with open(p, encoding='utf-8') as f: return json.load(f)
    except (OSError, ValueError): return None
def tl(p):
    try:
        with open(p, encoding='utf-8', errors='replace') as f: return f.read()
    except OSError: return None
def rel(a, b):
    a, b = float(a), float(b)
    return 0.0 if a == b else abs(a - b) / max(abs(b), 1e-300)
def iv(v):
    """[man, exp, radman, radexp] -> exact (lo, hi, mid, rad) as Fractions"""
    mid = Fraction(int(v[0])) * Fraction(2) ** int(v[1]); rad = Fraction(int(v[2])) * Fraction(2) ** int(v[3])
    return mid - rad, mid + rad, mid, rad
def overlap(a, b): return a[0] <= b[1] and b[0] <= a[1]
def fiv(lo, hi): return (lo, hi)
def show(v):
    """exact enclosure -> string 'mid +/- rad' (20 digits)"""
    lo, hi, mid, rad = iv(v)
    try:
        from flint import arb, ctx
        ctx.prec = 400
        m = arb(int(v[0])) * arb(2) ** int(v[1]); r = arb(int(v[2])) * arb(2) ** int(v[3])
        return arb(m, r).str(20)
    except Exception:
        return f'{float(mid):.17g} +/- {float(rad):.3g}'


# ------------------------------------------------------------------------------------------------------------------ environment
def check_env():
    e = jl(os.path.join(OUT, 'env.json'))
    if not e: add('WARN', 'environment', 'kit_out/env.json missing'); return {}
    v = e.get('versions', {}); pins = e.get('pinned', {})
    diff = {k: (v.get(k), p) for k, p in pins.items() if v.get(k) != p}
    add('PASS' if not diff else 'WARN', 'environment', f"Python {e['python'].split()[0]}, {e['platform']}; " +
        (', '.join(f'{k} {a} (ref {p})' for k, (a, p) in diff.items()) + ' differ from the reference pins' if diff else 'library versions equal the reference pins'))
    return e


# ------------------------------------------------------------------------------------------------------------------ (a) Gamma0 certificate
def check_gamma0():
    G = os.path.join(OUT, 'gamma0'); new = jl(os.path.join(G, 'gamma0_final.json')); ref = jl(os.path.join(REF, 'gamma0_final.json'))
    log = tl(os.path.join(OUT, 'logs', 'gamma0.log')); rlog = tl(os.path.join(REF, 'gamma0_final.log')) or ''
    info = dict(ok=False)
    if ref is None: add('FAIL', 'gamma0', 'reference/gamma0_final.json missing (broken kit)'); return info
    if new is None or log is None: add('FAIL', 'gamma0 certificate', 'output missing: kit_out/gamma0/gamma0_final.json or logs/gamma0.log'); return info
    add('PASS' if os.path.exists(os.path.join(G, 'gamma0.done')) else 'FAIL', 'gamma0: run completed', 'gamma0.done marker')
    # inputs
    same = all(new.get(k) == ref.get(k) for k in ('M', 'j', 'L0_hex', 'X0_hex', 't'))
    add('PASS' if same else 'FAIL', 'gamma0: input curve (M, L0, X0, t)', f"M={new.get('M')}, j={new.get('j')}, L0={new.get('L0')}" + ('' if same else '  DIFFERS from reference input'))
    # Krawczyk
    kr = re.search(r'Krawczyk:.*K\(X\) in int X: (True|False)', log); contr = new.get('krawczyk_contraction')
    ok = bool(kr) and kr.group(1) == 'True' and contr is not None and float(contr) < 1
    add('PASS' if ok else 'FAIL', 'gamma0: Krawczyk closure of b_2', f"K(X) strictly inside X: {kr.group(1) if kr else 'not found'}; |1 - C'(X)/c'| <= {float(contr):.3e} (< 1; ref {ref['krawczyk_contraction']:.3e})")
    # closing interval overlap
    def bj_iv(g):
        mid = Fraction(int(g['b_j_center_exact']['man'])) * Fraction(2) ** int(g['b_j_center_exact']['exp']); hw = Fraction(float(g['b_j_halfwidth'])); return mid - hw, mid + hw, mid, hw
    a, b = bj_iv(new), bj_iv(ref)
    ov = overlap(a, b)
    add('PASS' if ov else 'FAIL', 'gamma0: closing interval of b_2 overlaps ours', f"new halfwidth {float(new['b_j_halfwidth']):.4e}, ref {float(ref['b_j_halfwidth']):.4e} (rel diff {rel(new['b_j_halfwidth'], ref['b_j_halfwidth']):.1e}); |centre diff| = {float(abs(a[2] - b[2])):.2e}")
    # embeddedness
    e, r = new.get('embedded') or {}, ref['embedded']
    mt_ok = e.get('maxturn', 9) < math.pi / 2 and e.get('maxpair', 9) < math.pi
    rounds = re.findall(r'round (\d+) arcs (\d+) turning/precision violations (\d+) intersecting arcs (\d+)', log)
    last_ok = bool(rounds) and rounds[-1][2] == '0' and rounds[-1][3] == '0'
    mid_ok = 'middle y<0: True' in log
    emb_ok = mt_ok and last_ok and mid_ok and e.get('minsep', 0) > 0 and e.get('gap_cert', 0) > 0
    add('PASS' if emb_ok else 'FAIL', 'gamma0: embeddedness', f"arcs {e.get('arcs')} (ref {r['arcs']}); max arc turning {e.get('maxturn', float('nan')):.5f} < pi/2; max adjacent-pair turning {e.get('maxpair', float('nan')):.5f} < pi; "
        f"non-adjacent boxes disjoint (last refinement round: 0 violations, 0 intersecting: {last_ok}); middle arcs y<0: {mid_ok}; min box separation {e.get('minsep', float('nan')):.3e} (ref {r['minsep']:.3e}); slot half-gap >= {e.get('gap_cert', float('nan')):.7f} (ref {r['gap_cert']:.7f})")
    rd = {k: rel(e[k], r[k]) for k in ('gap_cert', 'minsep', 'maxturn', 'maxpair') if k in e}
    add('INFO', 'gamma0: relative differences to reference', ', '.join(f'{k} {v:.1e}' for k, v in rd.items()) + f"; arcs {e.get('arcs')} vs {r['arcs']}")
    # bit identity (bonus)
    bh = new.get('b_hex') == ref.get('b_hex'); cc = new['b_j_center_exact'] == ref['b_j_center_exact']; hw = new['b_j_halfwidth'] == ref['b_j_halfwidth']; nd = new.get('nodes_t') == ref.get('nodes_t')
    add('INFO', 'gamma0: bit-identity (bonus)', f"b_n doubles {'identical' if bh else 'DIFFER'}; b_2 centre (192 bit) {'identical' if cc else 'differs'}; b_2 halfwidth {'identical' if hw else 'differs'}; arc nodes {'identical' if nd else 'differ'}")
    info.update(ok=ok and ov and emb_ok and same, b2=(float(a[2]), float(a[3])), arcs=e.get('arcs'), minsep=e.get('minsep'), gap=e.get('gap_cert'), contr=contr, ident=(bh and cc and hw and nd))
    return info


# ------------------------------------------------------------------------------------------------------------------ (b), (c) P1 chain
RADII = ('w_out', 'eta_intra', 'hull1', 'box1', 'box3', 'T')

def check_p1():
    ref = jl(os.path.join(REF, 'p1_ref.json')); info = dict(n=0, full=False)
    if ref is None: add('FAIL', 'P1', 'reference/p1_ref.json missing (broken kit)'); return info
    rs = ref['slabs']
    C = os.path.join(OUT, 'p1', 'ckpt')
    recs = {}
    for k in range(0, 200):
        r = jl(os.path.join(C, f'slab_{k:05d}.json'))
        if r is None: break
        recs[k] = r
    if not recs: add('FAIL', 'P1 chain', 'no checkpoints in kit_out/p1/ckpt'); return info
    n = max(recs); info['n'] = n
    hist = {h['slab']: h for h in recs[n].get('history', [])}
    st = jl(os.path.join(OUT, 'p1', 'status.json')) or {}
    full = bool(st.get('done')) and float(st.get('target_k', 0)) >= FINAL_K and st.get('slab') == n and n == NSLABS
    info['full'] = full
    if full: add('PASS', f'P1: chain complete', f'{n} slabs (0 = Gamma0, 1..{n}); stop rule: k_max enclosure >= {st["target_k"]:g} reached at slab {n}')
    elif n > NSLABS: add('FAIL', 'P1: chain length', f'{n} slabs, the reference has {NSLABS}')
    else: add('WARN', f'P1: PARTIAL chain', f'{n} of {NSLABS} slabs present (run python run_all.py to continue); checks below cover slabs 0..{n} only')
    # certified: every slab present, complete, with a history record, finite radii; retries reported
    missing = [k for k in range(0, n + 1) if k not in recs or not recs[k].get('complete')]
    nohist = [k for k in range(1, n + 1) if k not in hist]
    badrad = [k for k in range(1, n + 1) if k in hist and not all(isinstance(hist[k].get(f), (int, float)) and math.isfinite(hist[k][f]) and hist[k][f] >= 0 for f in RADII)]
    retried = [k for k in range(1, n + 1) if k in hist and hist[k].get('attempt', 0) > 0]
    okc = not missing and not nohist and not badrad
    add('PASS' if okc else 'FAIL', 'P1: every slab certified (no failure)', f'{n}/{n} slabs have a complete checkpoint and a finite validated radius record'
        + ('' if okc else f'; missing {missing[:5]}, no history {nohist[:5]}, bad radii {badrad[:5]}') + f'; slabs that needed a retry (h/2, x10 cap; legitimate, still validated): {retried or "none"} (reference: none)')
    # discrete choices
    dis = []
    for k in range(1, min(n, NSLABS) + 1):
        h, q = hist.get(k, {}), rs[k]
        if recs[k]['M'] != q['M'] or recs[k]['d'] != q['d'] or (h.get('h') and rel(h['h'], q['h']) > 1e-9): dis.append(k)
    add('PASS' if not dis else 'INFO', 'P1: discrete choices (M, block, h) equal reference', 'all slabs equal (h to 1e-9)' if not dis else f'first difference at slab {dis[0]} ({len(dis)} slabs differ): the chain diverged from the reference there; later enclosures are for different time steps')
    # enclosure overlaps
    csv = ['slab,M,block,cpu_s,ref_cpu_s,t_overlap,L_overlap,X0_overlap,t_rad,ref_t_rad,' + ','.join(f'rd_{f}' for f in RADII)]
    bad = dict(t=[], L=[], X0=[]); idt = dict(t=0, L=0, X0=0); rdiff = {f: [] for f in RADII}
    for k in range(0, min(n, NSLABS) + 1):
        r, q = recs[k], rs[k]; line = [str(k), str(r['M']), str(r['d']), f"{hist.get(k, {}).get('cpu', 0):.1f}", f"{q.get('cpu', 0):.1f}"]
        for key in ('t', 'L', 'X0'):
            a, b = iv(r[key]), iv(q[key]); o = overlap(a, b); line.append('1' if o else '0')
            if not o: bad[key].append(k)
            if [str(x) for x in r[key]] == [str(x) for x in q[key]]: idt[key] += 1
        line += [f"{float(iv(r['t'])[3]):.3e}", f"{float(iv(q['t'])[3]):.3e}"]
        for f in RADII:
            if k >= 1 and k in hist and f in q and q[f] not in (None, 0):
                d = (float(hist[k][f]) - q[f]) / q[f]; rdiff[f].append((k, d)); line.append(f'{d:.2e}')
            else: line.append('')
        csv.append(','.join(line))
    # v3: common-time sanity check instead of plain overlap at slab ends (whose times differ by up to ~1e-15)
    nfail = {'L': [], 'X0': []}; worst = {'L': 0.0, 'X0': 0.0}; dtmax = 0.0; ncmp = 0
    for k in range(0, min(n, NSLABS) + 1):
        r, q = recs[k], rs[k]; tu, tr_ = iv(r['t']), iv(q['t']); dt = abs(tu[2] - tr_[2]); dtmax = max(dtmax, float(dt)); ncmp += 1
        for key in ('L', 'X0'):
            qu, qr = iv(r[key]), iv(q[key]); sl = []
            for a, b in ((k - 1, k), (k, k + 1)):
                if 0 <= a and b <= min(NSLABS, len(rs) - 1) and iv(rs[b]['t'])[2] != iv(rs[a]['t'])[2]:
                    sl.append(abs((iv(rs[b][key])[2] - iv(rs[a][key])[2]) / (iv(rs[b]['t'])[2] - iv(rs[a]['t'])[2])))
            Sq = 2 * max(sl) if sl else Fraction(0)
            allow = qu[3] + qr[3] + Sq * (dt + tu[3] + tr_[3]); diff = abs(qu[2] - qr[2])
            if diff > allow: nfail[key].append(k)
            if allow: worst[key] = max(worst[key], float(diff / allow))
    okt = not nfail['L'] and not nfail['X0']
    add('PASS' if okt else 'WARN', 'P1 sanity check: L and X0 at a common time agree with the reference (all slabs; not part of the acceptance)',
        f'{ncmp} slabs compared; worst |difference| / allowance: L {worst["L"]:.3g}, X0 {worst["X0"]:.3g} (1 = limit); max |t_u - t_r| over slab ends {dtmax:.2e}'
        + ('' if okt else f'; outside the allowance at L {nfail["L"][:8]}, X0 {nfail["X0"][:8]} (look; the acceptance rule does not depend on this line)'))
    nbad_t = len(bad['t']); add('INFO', 'P1: raw slab-end enclosure overlap t / L / X0 (informational: slab-end times differ between chains)',
        f'overlap in {ncmp - len(bad["t"])} / {ncmp - len(bad["L"])} / {ncmp - len(bad["X0"])} of {ncmp} slabs')
    # k_max
    kb = []; kn = 0; kmiss = []
    for k in range(1, min(n, NSLABS) + 1):
        q = rs[k].get('kmax'); h = hist.get(k, {}).get('kmax')
        if q:
            if not h: kmiss.append(k); continue
            kn += 1
            if not (max(h[0], q[0]) <= min(h[1], q[1])): kb.append(k)
    okk = not kb and not kmiss
    add('PASS' if okk else 'FAIL', 'P1: k_max enclosures overlap reference', f'{kn} slabs with a reported enclosure compared (reference reports k_max on slabs 94-96, where k > 20)' + ('' if okk else f'; no overlap at {kb}, not reported at {kmiss}'))
    # radii
    parts = []; worst = 0.0
    for f in RADII:
        v = rdiff[f]
        if not v: continue
        wk, wd = max(v, key=lambda x: abs(x[1])); med = statistics.median(abs(d) for _, d in v); worst = max(worst, abs(wd))
        parts.append(f'{f}: max {wd:+.1e} (slab {wk}), median |.| {med:.1e}')
    add('INFO', 'P1: relative differences of the error radii (new-ref)/ref', '; '.join(parts) if parts else 'none computable')
    add('PASS' if worst < 9 else 'WARN', 'P1: error radii within a factor 10 of reference', 'worst |relative difference| = %.2e' % worst + ('' if worst < 9 else ' (radii differ by more than a factor 10 somewhere; the chain still validated, please send the output)'))
    # bit identity
    nn = min(n, NSLABS) + 1
    import hashlib
    def h16(b): return hashlib.sha256(b).hexdigest()[:16]
    cnt = dict(xbar=0, G=0, w=0, box=0, rad=0)
    try:
        import numpy as np
        for k in range(nn):
            q = rs[k]; r = recs[k]
            if h16(json.dumps(r['xbar']).encode()) == q.get('sha_xbar'): cnt['xbar'] += 1
            with np.load(os.path.join(C, f'slab_{k:05d}.npz')) as z:
                if h16(np.ascontiguousarray(z['G'], dtype='<f8').tobytes()) == q.get('sha_G'): cnt['G'] += 1
                if h16(np.ascontiguousarray(z['w'], dtype='<f8').tobytes()) == q.get('sha_w'): cnt['w'] += 1
                if h16(np.ascontiguousarray(z['box'], dtype='<f8').tobytes()) == q.get('sha_box'): cnt['box'] += 1
            if k >= 1 and all(hist.get(k, {}).get(f) == q.get(f) for f in RADII): cnt['rad'] += 1
        bi = f"128-bit centres (xbar) identical in {cnt['xbar']}/{nn} slabs; parallelepiped G {cnt['G']}/{nn}, radii w {cnt['w']}/{nn}, box {cnt['box']}/{nn}; reported radii records identical {cnt['rad']}/{nn - 1}; t / L / X0 enclosures identical {idt['t']}/{idt['L']}/{idt['X0']} of {nn}"
    except Exception as ex:
        bi = 'not computed: ' + repr(ex)
    add('INFO', 'P1: bit-identity (bonus, not required)', bi)
    info['bit'] = cnt; info['bit_n'] = nn; info['idt'] = idt
    # cpu
    cpu = sum(h.get('cpu', 0) for h in hist.values()); rcpu = sum(rs[k].get('cpu', 0) for k in range(1, min(n, NSLABS) + 1))
    add('INFO', 'P1: cpu time', f'{cpu / 3600:.2f} h for slabs 1..{n} (reference {rcpu / 3600:.2f} h on the sandbox): speed ratio {cpu / rcpu if rcpu else float("nan"):.2f}x')
    # (c) final slab
    rec = recs[n]; q = rs[min(n, NSLABS)]
    finfo = {}
    for key in ('t', 'L', 'X0'):
        finfo[key] = (show(rec[key]), show(q[key]), overlap(iv(rec[key]), iv(q[key])))
    h = hist.get(n, {}); kn_ = h.get('kmax'); kq = q.get('kmax')
    finfo['kmax'] = (kn_, kq, bool(kn_ and kq and max(kn_[0], kq[0]) <= min(kn_[1], kq[1])))
    info['final'] = finfo; info['final_slab'] = n
    if full:
        fo = all(finfo[k][2] for k in finfo)
        rf = ref['final']
        add('PASS' if fo else 'FAIL', f'P1: final slab {n}: t, L, X0, k_max overlap reference', f"t {finfo['t'][0]}  (ref {finfo['t'][1]});  L {finfo['L'][0]}  (ref {finfo['L'][1]});  X0 {finfo['X0'][0]}  (ref {finfo['X0'][1]});  k_max in {kn_} (ref {kq})")
        kok = bool(kn_) and kn_[0] >= FINAL_K
        add('PASS' if kok else 'FAIL', f'P1: final k_max enclosure >= {FINAL_K:g}', f'k_max in [{kn_[0]!r}, {kn_[1]!r}]' if kn_ else 'k_max not reported')
        dmb = []
        if st:
            dmb.append(f"M {st.get('M')} vs {rf['M']}, block {st.get('block')} vs {rf['block']}")
            for nm, a, b in (('theta_max', st.get('theta_max'), rf['theta_max']), ('rho_max', st.get('rho_max'), rf['rho_max']), ('C2', st.get('C2'), rf['C2']), ('C5_lead', st.get('C5_lead'), rf['C5_lead'])):
                if a is not None: dmb.append(f'{nm} {a:.4e} vs {b:.4e} (rel {rel(a, b):.1e})')
            for j, (a, b) in enumerate(zip(st.get('e_norms', []), rf['e_norms'])): dmb.append(f'|e|_{j} rel {rel(a, b):.1e}')
        add('INFO', 'P1: final-slab error budget vs reference', '; '.join(dmb))
    else:
        add('INFO', f'P1: slab {n} enclosures (partial run)', f"t {finfo['t'][0]} (ref {finfo['t'][1]}); L {finfo['L'][0]} (ref {finfo['L'][1]}); X0 {finfo['X0'][0]} (ref {finfo['X0'][1]})")
    try:
        with open(os.path.join(OUT, 'check_slabs.csv'), 'w', encoding='utf-8') as f: f.write('\n'.join(csv) + '\n')
    except OSError: pass
    return info


# ------------------------------------------------------------------------------------------------------------------ main
def main():
    env = check_env(); g = check_gamma0(); p = check_p1()
    nf = sum(1 for r in rows if r[0] == 'FAIL'); nw = sum(1 for r in rows if r[0] == 'WARN'); npass = sum(1 for r in rows if r[0] == 'PASS')
    full = p.get('full', False)
    if full: verdict = 'TOTAL PASS' if nf == 0 else 'TOTAL FAIL'
    else: verdict = ('PARTIAL PASS' if nf == 0 else 'PARTIAL FAIL') + f' (slabs 0..{p.get("n", 0)} of {NSLABS}; not a full result)'
    L = []
    w = L.append
    w('=' * 100); w('KIT 4A ' + KIT_VERSION + ' check:  Gamma0 certificate + P1 validated chain   vs reference/'); w('=' * 100)
    for st, nm, d in rows:
        w(f'{st:5s}  {nm}');
        if d: w(f'         {d}')
    w('-' * 100)
    w('Rule: PASS needs (i) Gamma0 certified and b_2 interval overlapping ours, (ii) every slab validated, (iii) k_max (reported slabs) overlapping ours; the L / X0 common-time line is a sanity check (WARN only),')
    w('      (iv) final slab enclosures overlapping and k_max >= 28.  INFO lines (radius differences, bit-identity, timings) are reported, not required.  WARN = look, not a failure.')
    w('')
    w('=' * 30 + ' SUMMARY (paste this) ' + '=' * 30)
    w(f'{verdict}   [{npass} PASS, {nf} FAIL, {nw} WARN]')
    if env:
        e = jl(os.path.join(OUT, 'env.json')) or {}; v = e.get('versions', {})
        w(f"env: Python {e.get('python', '?').split()[0]} | {e.get('platform', '?')} | flint {v.get('flint')} numpy {v.get('numpy')} scipy {v.get('scipy')}")
    if g.get('b2'):
        w(f"Gamma0: certificate {'OK' if g['ok'] else 'NOT OK'}; Krawczyk contraction {float(g['contr']):.2e}; b_2 = {g['b2'][0]:.17g} +/- {g['b2'][1]:.2e}; embedded: {g['arcs']} arcs, min box separation {g['minsep']:.3e}, slot half-gap >= {g['gap']:.6f}; bit-identical to reference: {g['ident']}")
    else: w('Gamma0: certificate NOT OK / missing')
    if p.get('n'):
        w(f"P1: {p['n']} of {NSLABS} slabs validated" + ('' if full else '  (PARTIAL)'))
        fi = p['final']
        km = lambda x: f'in {x}' if x else '(not reported on this slab)'
        w(f"final slab {p['final_slab']}:  t = {fi['t'][0]}   L = {fi['L'][0]}   X0 = {fi['X0'][0]}   k_max {km(fi['kmax'][0])}")
        w(f"  reference:      t = {fi['t'][1]}   L = {fi['L'][1]}   X0 = {fi['X0'][1]}   k_max {km(fi['kmax'][1])}")
        w(f"  overlap with reference:  t {fi['t'][2]}, L {fi['L'][2]}, X0 {fi['X0'][2]}" + (f", k_max {fi['kmax'][2]}" if fi['kmax'][0] or fi['kmax'][1] else ''))
        b = p.get('bit', {}); nn = p.get('bit_n', 0)
        if b: w(f"bit-identity (bonus): centres {b['xbar']}/{nn}, G {b['G']}/{nn}, radii-w {b['w']}/{nn}, t/L/X0 enclosures identical {p['idt']['t']}/{p['idt']['L']}/{p['idt']['X0']}")
        for st_, nm, d in rows:
            if nm.startswith('P1: relative differences') or nm.startswith('P1: cpu'): w(f'{nm}: {d}')
    w('=' * 82)
    text = '\n'.join(L)
    print(text)
    try:
        with open(os.path.join(OUT, 'check_report.txt'), 'w', encoding='utf-8') as f: f.write(text + '\n')
    except OSError: pass
    return 0 if nf == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
