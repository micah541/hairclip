#!/usr/bin/env python3
"""Far-cylinder margin-2 case of Lemma O v3 (key 'far_margin2' of lemmaO_v3_consts.json): X=2, M=1, K2=K3=1.5, f=1/2, L=113 (lambda_1 units).
Kit driver: same call as the original ad-hoc run (/tmp/far2.py of the source session); writes far_margin2.json in the current directory."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as F
import lemmaO_v3_interval as I
L = 113; need = 1.0 / L**4
r = I.case('far margin2 X=2 M=1', F(2), F(1), F(3, 2), F(3, 2), F(1, 2), need, grid=10)
out = dict(L=L, case=r, note='cylinder length unit L=113 lambda1, t1=1 (lambda1^4); jets in cylinder units M=1 => physical m_j<=L^(1-j)')
json.dump(out, open('far_margin2.json', 'w', encoding='utf-8'), indent=1)
print(r['t_star_lower'], r['needed'], r['margin_factor_lower'], r['deviation_upper_at_needed_time'], r['K3_minus_g3_global_term'], r['slope_actual_margin_lower'])
